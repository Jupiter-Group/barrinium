# webKDE
KDE Plasma clone written in JS.
![screenshot](/screenshots/screenshot.png)
